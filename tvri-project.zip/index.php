<?php

session_start();
include 'config/koneksi.php';
$loggedIn = isset($_SESSION['user']);
$role = $loggedIn ? $_SESSION['user']['role'] : null;

$queryError = false;


// Ambil lokasi (default Senayan)
$lokasi = isset($_GET['lokasi']) ? $_GET['lokasi'] : 'Senayan';

// Ambil kata kunci pencarian (default kosong)
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Siapkan array kata kunci
$searchTerms = [];
if ($search !== '') {
    $parts = preg_split('/\s+/u', $search, -1, PREG_SPLIT_NO_EMPTY);
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p !== '') {
            $searchTerms[] = $p;
        }
    }
}

// Kondisi WHERE
$where = [];
$where[] = "tanggal = CURDATE()"; // selalu jadwal hari ini

if ($lokasi !== 'Semua') {
    $lokasiEsc = $conn->real_escape_string($lokasi);
    $where[] = "lokasi = '{$lokasiEsc}'";
}

if (!empty($searchTerms)) {
    $columns = ['nip', 'nama', 'shift', 'jam', 'pekerjaan', 'lokasi'];
    foreach ($searchTerms as $term) {
        $termEsc = $conn->real_escape_string($term);
        $like = "%{$termEsc}%";
        $orParts = [];
        foreach ($columns as $col) {
            $orParts[] = "{$col} LIKE '{$like}'";
        }
        $where[] = '(' . implode(' OR ', $orParts) . ')';
    }
}

// Susun query akhir
// Susun query akhir (pakai filter lokasi dan pencarian)
$sql = "SELECT jk.*, p.nama 
        FROM jadwal_karyawan jk
        LEFT JOIN pegawai p ON jk.id_pegawai = p.id";

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY p.nama ASC";

$result = $conn->query($sql);


// Fungsi highlight
function highlight_terms($text, $terms)
{
    if ($text === null || $text === '') {
        return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
    }
    if (empty($terms)) {
        return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
    }

    usort($terms, fn ($a, $b) => mb_strlen($b) - mb_strlen($a));
    $escapedPatterns = array_map(fn ($t) => preg_quote($t, '/'), $terms);
    $pattern = '/(' . implode('|', $escapedPatterns) . ')/iu';
    $parts = preg_split($pattern, $text, -1, PREG_SPLIT_DELIM_CAPTURE);

    if ($parts === false) {
        return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
    }

    $out = '';
    foreach ($parts as $part) {
        if ($part === '') {
            continue;
        }
        if (preg_match($pattern, $part)) {
            $out .= '<mark class="bg-warning text-dark">' . htmlspecialchars($part, ENT_QUOTES, 'UTF-8') . '</mark>';
        } else {
            $out .= htmlspecialchars($part, ENT_QUOTES, 'UTF-8');
        }
    }
    return $out;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Jadwal Hari Ini — Sistem Jadwal</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
  <!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="d-flex align-items-center justify-content-between px-3 mb-3">
    <div class="d-flex align-items-center gap-2">
      <button id="pinSidebar" class="pin-btn" title="Collapse/Expand">📌</button>
      <h4 class="m-0 ms-3 text-light">MENU</h4>
    </div>
  </div>
  <a href="index.php">🏠 <span class="menu-text">Beranda</span></a>
  <a href="pages/jadwalbulanan.php">📅 <span class="menu-text">Jadwal Bulanan</span></a>
  <a href="pages/rekap.php">✉️ <span class="menu-text">Rekap</span></a>

  <?php if ($loggedIn): ?>
      <a href="pages/tambahpegawai.php">➕ <span class="menu-text">Tambah Pegawai</span></a>
      <a href="pages/tambahjadwal_otomatis.php">➕ <span class="menu-text">Tambah Jadwal</span></a>
      <a href="logout.php" class="text-danger">🚪 <span class="menu-text">Logout (<?= htmlspecialchars($_SESSION['user']['username']) ?>)</span></a>
  <?php else: ?>
      <a href="login.php" class="text-success">🔑 <span class="menu-text">Login</span></a>
  <?php endif; ?>
</aside>


  <!-- Main -->
  <main class="main">
    <!-- Topbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm rounded mb-4">
      <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center" href="#">
          <img src="assets/images/TVRI.png" alt="TVRI" width="90" class="me-2">
        </a>
        <form method="get" class="d-flex flex-grow-1 mx-3">
          <input class="form-control me-2 flex-grow-1"
                 id="searchInput"
                 name="search"
                 type="text"
                 placeholder="Cari ID / Nama / Pekerjaan"
                 value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">

          <select class="form-select me-2" style="width:150px;" name="lokasi" onchange="this.form.submit()">
            <option value="Senayan" <?= $lokasi === 'Senayan' ? 'selected' : ''; ?>>Senayan</option>
            <option value="Joglo"   <?= $lokasi === 'Joglo' ? 'selected' : ''; ?>>Joglo</option>
            <option value="Semua"   <?= $lokasi === 'Semua' ? 'selected' : ''; ?>>Semua</option>
          </select>

          <button class="btn btn-primary" type="submit">🔍 Cari</button>
        </form>
      </div>
    </nav>
    

<!-- Content -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="fw-bold">📋 Jadwal Hari Ini</h2>
  </div>

    <div class="card shadow">
      <div class="card-header bg-primary text-white">
        Jadwal Lokasi: <?= htmlspecialchars($lokasi, ENT_QUOTES, 'UTF-8') ?>
      </div>
      <div class="card-body">
        <?php if ($queryError): ?>
          <div class="alert alert-warning">Terjadi kesalahan mengambil data. Silakan cek log server.</div>
        <?php endif; ?>

        <?php if ($search !== '' && !$queryError): ?>
          <div class="alert alert-info mb-3">
            Hasil pencarian untuk: <strong><?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?></strong>
            (<?= $result ? $result->num_rows : 0 ?> data ditemukan)
          </div>
        <?php endif; ?>

        <div class="table-responsive">
          <table class="table table-striped table-hover align-middle" id="scheduleTable">
            <thead class="table-dark">
              <tr>
                <th>Nama Petugas</th>
                <th>Tanggal</th>
                <th>Shift</th>
                <th>Jam</th>
                <th>Lokasi</th>
              </tr>
            </thead>
            <tbody>
            <?php
              if ($result && $result->num_rows > 0) {
                  while ($row = $result->fetch_assoc()) {
                      $shiftVal = $row['shift'] ?? '';
                      $fileHTML = "-";
                      if (!empty($row['file_path'])) {
                          $filename = basename(str_replace('\\', '/', $row['file_path']));
                          $fileUrl = "uploads/" . $filename;
                          $fileHTML = "<a href='" . htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8') . "' target='_blank' class='btn btn-sm btn-outline-info'>Lihat File</a>";
                      }
                      echo "<tr>".
                           "<td>".highlight_terms($row['nama'] ?? '', $searchTerms)."</td>".
                           "<td>".highlight_terms($row['tanggal'] ?? '', $searchTerms)."</td>".
                           "<td>".highlight_terms($shiftVal, $searchTerms)."</td>".
                           "<td>".highlight_terms($row['jam'] ?? '', $searchTerms)."</td>".
                           "<td>".highlight_terms($row['lokasi'] ?? '', $searchTerms)."</td>".
                           "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='8' class='text-center'>⚠️ Tidak ada data</td></tr>";
              }
?>
            </tbody>
          </table>
        </div>
        <!-- Tabel Liputan -->
         <?php if ($loggedIn): ?>
            <div class="mb-3">
                <a href="./pages/tambah_liputan.php" class="btn btn-success">➕ Tambah Kegiatan</a>
            </div>
          <?php endif; ?>

        </div>
         <div class="table-responsive">
          <table class="table table-striped table-hover align-middle" id="scheduleTable">
            <thead class="table-dark">
              <tr>
                <th>Nama Petugas</th>
                <th>Lokasi</th>
                <th>Jenis Kegiatan</th>
                <th>Tanggal</th>
                <th>Surat Tugas</th>
              </tr>
            </thead>

            <tbody>
            <?php
                include './config/koneksi.php';

                // Ambil data dari tabel liputan
                $result = $conn->query("
                                          SELECT 
                                              p.nama AS nama_petugas,
                                              l.lokasi,
                                              l.jenis_kegiatan,
                                              l.tanggal,
                                              l.surat_tugas
                                          FROM liputan l
                                          JOIN pegawai p ON l.id_pegawai = p.id
                                          ORDER BY l.id DESC
                                        ");


                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {

                        // Siapkan tombol file (jika ada surat tugas)
                        $fileHTML = "-";
                        if (!empty($row['surat_tugas'])) {
                            // Ambil nama file dari path
                            $filename = basename(str_replace('\\', '/', $row['surat_tugas']));
                            // Path relatif (karena file disimpan di ../uploads)
                            $fileUrl = "uploads/" . $filename;
                            $fileHTML = "<a href='" . htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8') . "' target='_blank' class='btn btn-sm btn-outline-info'>📄 Lihat</a>";
                        }

                        echo "<tr>
                                <td>" . htmlspecialchars($row['nama_petugas']) . "</td>
                                <td>" . htmlspecialchars($row['lokasi']) . "</td>
                                <td>" . htmlspecialchars($row['jenis_kegiatan']) . "</td>
                                <td>" . htmlspecialchars($row['tanggal']) . "</td>
                                <td>" . $fileHTML . "</td>
                              </tr>";

                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>⚠️ Tidak ada data liputan</td></tr>";
                }

                $conn->close();
                ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <script src="assets/js/script.js"></script>
</body>
</html>
